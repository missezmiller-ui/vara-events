# Vara Events – Next.js + Tailwind Starter

## Run locally
```bash
npm install
npm run dev
# visit http://localhost:3000
```

## Deploy to Vercel
1. Push this folder to a new GitHub repo.
2. In Vercel, click **Add New > Project**, import your repo.
3. Framework preset: **Next.js** (autodetected). Build command: `next build`. Output: `.next`.
4. Deploy.
