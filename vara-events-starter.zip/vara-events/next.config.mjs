export default {
  reactStrictMode: true,
}
